#include "Exit.h"

//-----------------------------------------------------------------------------
void Exit::execute(sf::RenderWindow& window)
{
	window.close();
}