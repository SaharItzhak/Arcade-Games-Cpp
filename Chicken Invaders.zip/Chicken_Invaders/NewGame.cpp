#include "NewGame.h"
#include "GameManager.h"

//-----------------------------------------------------------------------------
void NewGame::execute(sf::RenderWindow& window)
{
	window.clear();
	GameManager game;
}