#pragma once
#include "Players.h"

class User : public Players
{
public:
	User();
	~User();
	void newColor(sf::Color);
};

