#include "Restart.h"
#include "Controller.h"


Restart::Restart()
{
}


Restart::~Restart()
{
}

void Restart::clickedOn(Controller & c)
{
	c.restart();
}
