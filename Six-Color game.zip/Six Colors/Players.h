#pragma once
#include "Shapes.h"

class Players
{
public:
	Players();
	~Players();
	void start(Shapes *);

protected:

	std::set<Shapes *> m_setShapes;
};

