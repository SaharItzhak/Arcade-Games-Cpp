#include "Diamond.h"



Diamond::Diamond(std::vector<sf::Vector2f> vec) : Shapes(VERTEX_DI, vec)
{
	
}


Diamond::~Diamond()
{
}
