#include "Yellow.h"
#include "Controller.h"

Yellow::Yellow()
{
}

Yellow::~Yellow()
{
}

void Yellow::clickedOn(Controller & c)
{
	c.yellow();
}
