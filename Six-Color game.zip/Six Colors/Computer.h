#pragma once
#include "Players.h"

class Computer : public Players
{
public:
	Computer();
	~Computer();
};

