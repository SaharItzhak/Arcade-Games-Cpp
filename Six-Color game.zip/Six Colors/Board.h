#pragma once
#include <iostream>
#include <vector>
#include "Utilities.h"
#include "Controller.h"			//maybe circle include
#include "Shapes.h"
#include "Triangle.h"
#include "Diamond.h"
#include "User.h"

class Board
{
public:
	Board(User &);
	~Board();
	void draw(sf::RenderWindow &);
	void Edges();
	void centerMat();
	Shape_kind get();
	void neighbors();



private:	
	//typedef std::pair<Shape_kind, std::pair<Shapes *, Shapes * >> p_type;
	//typedef std::vector<p_type> l_type;
	//typedef std::vector<l_type> m_type;

	m_type m_board;
	User &m_user;

	std::vector<Shapes*> m_shapes;
	sf::RectangleShape m_rec;

	std::vector<sf::Vector2f> vec_one;
	std::vector<sf::Vector2f> vec_two;
	std::vector<sf::Vector2f> vec_dia;	//diamond 
	
};

