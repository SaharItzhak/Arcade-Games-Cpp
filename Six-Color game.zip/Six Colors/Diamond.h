#pragma once
#include "Shapes.h"

class Diamond : public Shapes
{
public:
	Diamond() = default;
	Diamond(std::vector<sf::Vector2f>);
	~Diamond();
};

