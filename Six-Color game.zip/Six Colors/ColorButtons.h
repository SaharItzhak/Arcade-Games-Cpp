#pragma once
#include "Buttons.h"

class ColorButtons : public Buttons
{
public:
	ColorButtons();
	~ColorButtons();
	virtual void clickedOn(Controller &) = 0;
};

