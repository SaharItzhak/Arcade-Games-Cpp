#include "Computer.h"



Computer::Computer()
{
}


Computer::~Computer()
{
}
