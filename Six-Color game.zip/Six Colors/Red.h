#pragma once
#include "ColorButtons.h"

class Red : public ColorButtons
{
public:
	Red();
	~Red();
	virtual void clickedOn(Controller &);

private:
};
