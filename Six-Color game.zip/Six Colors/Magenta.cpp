#include "Magenta.h"
#include "Controller.h"

Magenta::Magenta()
{
}

Magenta::~Magenta()
{
}

void Magenta::clickedOn(Controller & c)
{
	c.magenta();
}
