#include "GameButtons.h"

GameButtons::GameButtons()
{
}


GameButtons::~GameButtons()
{
}
