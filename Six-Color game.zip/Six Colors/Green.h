#pragma once
#include "ColorButtons.h"

class Green : public ColorButtons
{
public:
	Green();
	~Green();
	virtual void clickedOn(Controller &);


private:

};

