#pragma once
#include "GameButtons.h"

class Exit : public GameButtons
{
public:
	Exit();
	~Exit();
	virtual void clickedOn(Controller &);
};

