#pragma once
#include "ColorButtons.h"

class Magenta : public ColorButtons
{
public:
	Magenta();
	~Magenta();
	virtual void clickedOn(Controller & c);

private:

};
