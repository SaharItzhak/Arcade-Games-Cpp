#include "Shapes.h"
#include <iostream>



Shapes::Shapes()
{
}

Shapes::Shapes(int v, std::vector<sf::Vector2f> vec) : m_con(v), m_vec(vec)
{
	create();
}


Shapes::~Shapes()
{
}

void Shapes::create()
{
	for (int i = 0; i < m_vec.size(); ++i)
		m_con.setPoint(i, m_vec[i]);

	m_con.setFillColor(randomColor());
	m_con.setOutlineThickness(1);
	m_con.setOutlineColor(sf::Color::White);
	m_con.setPosition(10, 10);
}

void Shapes::draw(sf::RenderWindow & m_window)
{
	m_window.draw(m_con);
}

sf::Color Shapes::randomColor()
{
	int c = rand() % 6;
	if (c == 0)
		return(sf::Color::White);
	else if (c == 1)
		return(sf::Color::Magenta);
	else if (c == 2)
		return(sf::Color::Red);
	else if (c == 3)
		return(sf::Color::Blue);
	else if (c == 4)
		return(sf::Color::Green);
	else if (c == 5)
		return(sf::Color::Yellow);
		
}


void Shapes::setUpRightNeib(p_type &neighbor)
{
	if (neighbor.second.first == NULL)
		return;

	if (neighbor.first == TRAINGLE_HOR)
	{
		if (neighbor.second.second == NULL)
			return;
		m_nei.push_back(neighbor.second.second);
		return;
	}
	m_nei.push_back(neighbor.second.first);
}

void Shapes::setUpLeftNeib(p_type &neighbor)
{
	if (neighbor.second.second == NULL)
		return;

	if (neighbor.first == DIAMOND || neighbor.first == EDGE)
	{
		if (neighbor.second.first == NULL)
			return;
		m_nei.push_back(neighbor.second.first);
		return;
	}
	m_nei.push_back(neighbor.second.second);

}

void Shapes::setDownLeftNeib(p_type &neighbor)
{
	if (neighbor.second.first == NULL)
		return;

	if (neighbor.first == TRAINGLE_VER)
	{
		if (neighbor.second.second == NULL)
			return;
		m_nei.push_back(neighbor.second.second);
		return;
	}
	m_nei.push_back(neighbor.second.first);
}

void Shapes::setDownRightNeib(p_type &neighbor)
{
	if (neighbor.second.first == NULL)
		return;
	m_nei.push_back(neighbor.second.first);
}

void Shapes::setTriNeib(Shapes * neighbor)
{
	m_nei.push_back(neighbor);
}


sf::Color Shapes::getColor()
{
	return m_con.getFillColor();
}

void Shapes::changeColor(sf::Color color, std::set<Shapes*> &shapeList)
{
	for (auto &j : m_nei)
	{
		if (shapeList.find(j) == shapeList.end())
		{
			if (j->getColor() == color)
			{
				//j->m_key = ++counter;
				&shapeList.insert(j);
				//addNeib(tri, dia);
			}
		}
	}
	m_con.setFillColor(color);
}