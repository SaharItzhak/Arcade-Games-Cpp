#pragma once
#include "Shapes.h"

class Triangle : public Shapes
{
public:
	Triangle() = default;
	Triangle(std::vector<sf::Vector2f>);
	~Triangle();
};

