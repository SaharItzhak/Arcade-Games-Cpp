#include "Exit.h"
#include "Controller.h"


Exit::Exit()
{
}


Exit::~Exit()
{
}

void Exit::clickedOn(Controller & c)
{
	c.exit();
}
