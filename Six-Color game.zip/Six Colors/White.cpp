#include "White.h"
#include "Controller.h"

White::White()
{
}

White::~White()
{
}

void White::clickedOn(Controller & c)
{
	c.white();
}
