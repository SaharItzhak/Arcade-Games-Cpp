#include "Green.h"
#include "Controller.h"

Green::Green()
{
}

Green::~Green()
{
}

void Green::clickedOn(Controller & c)
{
	c.green();
}
