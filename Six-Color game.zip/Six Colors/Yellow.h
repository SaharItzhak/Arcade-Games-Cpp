#pragma once
#include "ColorButtons.h"

class Yellow : public ColorButtons
{
public:
	Yellow();
	~Yellow();
	virtual void clickedOn(Controller &);

private:

};
