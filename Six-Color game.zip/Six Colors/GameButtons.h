#pragma once
#include "Buttons.h"

class GameButtons : public Buttons
{
public:
	GameButtons();
	~GameButtons();
	virtual void clickedOn(Controller &) = 0;
};

