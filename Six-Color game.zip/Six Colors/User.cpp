#include "User.h"



User::User()
{
}


User::~User()
{
}

void User::newColor(sf::Color color)
{
	for (auto& i : m_setShapes)
		i->changeColor(color, m_setShapes);
}
