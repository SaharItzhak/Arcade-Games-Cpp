#include "Controller.h"
#include "Board.h"
#include "GraphicsManager.h"
#include "Magenta.h"
#include "Green.h"
#include "Yellow.h"
#include "Red.h"
#include "Blue.h"
#include "White.h"
#include "Restart.h"
#include "Exit.h"



Controller::Controller()
{
	buttons();
}


Controller::~Controller()
{
}

void Controller::run()
{
	m_window.create(sf::VideoMode(700, 700), "Map Editor", sf::Style::Close);

	Board b(u);
	while (m_window.isOpen())
	{
		event();
		m_window.clear(/*sf::Color::White*/);
		drawTool();
		b.draw(m_window);
		m_window.display();
	}
}

void Controller::event()
{
	sf::Event event;
	while (m_window.pollEvent(event))
	{
		//close when x is pressed
		switch (event.type)
		{
		case sf::Event::Closed:
			m_window.close();
			break;

		case sf::Event::KeyPressed:
			switch (event.key.code)
			{
			case sf::Keyboard::Escape:
				m_window.close();
				break;
			}
		case sf::Event::MouseButtonReleased:
		{
			if (event.mouseButton.button == sf::Mouse::Button::Left)
			{
				sf::Vector2f pos = sf::Vector2f(sf::Mouse::getPosition(m_window));

				for (int i = 0; i < m_gameButton.size(); ++i) 
				{
					if (m_gameButton[i] != nullptr && m_gameButton[i]->containsGameButtons(pos, i))
						m_gameButton[i]->clickedOn(*this);
					
				}

				//for (auto &i : m_colorButtons)
				for(int i=0; i<m_colorButtons.size(); ++i)
				{
					if (m_colorButtons[i] != nullptr && m_colorButtons[i]->contains(pos, i))
						m_colorButtons[i]->clickedOn(*this);
				}
			}
		}
		}
	}


}

void Controller::drawTool()
{
	for (int i = 0; i < TOOL_BAR; ++i)
	{
		auto sprite = *GraphicsManager::get_instance().getTexture(i);
		sf::Sprite s(sprite);
		s.setPosition(100 * i, 0);
		m_window.draw(s);
	}

	for (int i = 0; i < COLORS; i++)
	{
		auto sprite = *GraphicsManager::get_instance().getTextureColor(i);
		sf::Sprite s(sprite);
		s.setPosition(92 * (i + 1), 600);
		m_window.draw(s);
	}

}

void Controller::buttons()
{
	m_colorButtons.push_back(new Blue); 
	m_colorButtons.push_back(new Green); 
	m_colorButtons.push_back(new White); 
	m_colorButtons.push_back(new Magenta); 
	m_colorButtons.push_back(new Red); 
	m_colorButtons.push_back(new Yellow); 

	m_gameButton.push_back(new Restart);
	m_gameButton.push_back(new Exit);
}

void Controller::blue()
{
	u.newColor(sf::Color::Blue);
}

void Controller::green()
{
	u.newColor(sf::Color::Green);
}

void Controller::white()
{
	u.newColor(sf::Color::White);
}

void Controller::magenta()
{
	u.newColor(sf::Color::Magenta);
}

void Controller::red()
{
	u.newColor(sf::Color::Red);
}

void Controller::yellow()
{
	u.newColor(sf::Color::Yellow);
}

void Controller::restart()
{
	run();
}

void Controller::exit()
{
	m_window.close();
}
