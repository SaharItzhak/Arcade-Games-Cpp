#pragma once
#include "ColorButtons.h"

class Blue : public ColorButtons
{
public:
	Blue();
	~Blue();
	virtual void clickedOn(Controller &);

private:

};

