#pragma once
#include <vector>

class Shapes;
#define VERTEX_TR 3
#define VERTEX_DI 4
#define TOOL_BAR 2 
#define COLORS 6 

enum Shape_kind { DIAMOND, TRAINGLE_HOR, TRAINGLE_VER, EDGE };

typedef std::pair<Shape_kind, std::pair<Shapes *, Shapes * >> p_type;
typedef std::vector<p_type> l_type;
typedef std::vector<l_type> m_type;
