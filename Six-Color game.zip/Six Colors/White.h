#pragma once
#include "ColorButtons.h"

class White : public ColorButtons
{
public:
	White();
	~White();
	virtual void clickedOn(Controller &);

private:

};
