#pragma once
#include <SFML/Graphics.hpp>
#include"Utilities.h"
#include <iostream>
#include <set>

class Shapes
{
public:
	Shapes();
	Shapes(int, std::vector<sf::Vector2f>);
	~Shapes();
	void create();
	void draw(sf::RenderWindow &);
	sf::Color randomColor();
	
	void setUpRightNeib(p_type &);
	void setUpLeftNeib(p_type &);
	void setDownLeftNeib(p_type &);
	void setDownRightNeib(p_type &);
	void setTriNeib(Shapes *);

	sf::Color getColor();
	void changeColor(sf::Color color, std::set<Shapes*> &shapeList);

private:
	sf::ConvexShape m_con;
	std::vector<sf::Vector2f> m_vec;
	std::vector<Shapes *> m_nei;
};

