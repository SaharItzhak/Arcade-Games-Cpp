#include "Board.h"

Board::Board(User & usr) : m_user(usr)
{
	vec_one.resize(3);
	vec_two.resize(3);
	vec_dia.resize(4);
	//m_rec.setPosition(50, 50);
	//m_rec.setFillColor(sf::Color::Blue);
	
	Edges();
	centerMat();
}


Board::~Board()
{
}

void Board::draw(sf::RenderWindow & m_window)
{
	//m_window.draw(m_rec);
	for (int i = 0; i < m_shapes.size(); ++i)
		m_shapes[i]->draw(m_window);
	
	//for (auto & i : m_shapes)
	//	i->draw(m_window);
}

void Board::Edges()
{
	l_type top;
	l_type bot;
	l_type side;

	//Top line
	vec_one[0] = { 50.f, 50.f };
	vec_one[1] = { 50.f, 70.f };
	vec_one[2] = { 70.f, 50.f };

	m_shapes.push_back(new Triangle(vec_one));
	int size = m_shapes.size();
	top.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	
	for (size_t i = 1; i < 14; ++i)
	{
		vec_one[0] = { 30.f + (float)i * 40.f , 50.f };
		vec_one[1] = { 50.f + (float)i * 40.f, 70.f };
		vec_one[2] = { 70.f + (float)i * 40.f , 50.f };
		m_shapes.push_back(new Triangle(vec_one));
		size = m_shapes.size();
		top.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	}

	vec_one[0] = { 610.f , 50.f };
	vec_one[1] = { 610.f , 70.f };
	vec_one[2] = { 590.f , 50.f };

	m_shapes.push_back(new Triangle(vec_one));
	size = m_shapes.size();
	top.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	
	//Bottom line
	vec_two[0] = { 50.f, 550.f };
	vec_two[1] = { 50.f, 570.f };
	vec_two[2] = { 70.f, 570.f };
	m_shapes.push_back(new Triangle(vec_two));
	size = m_shapes.size();
	bot.push_back({ EDGE, {m_shapes[size - 1], NULL } });

	m_user.start(m_shapes[size - 1]);

	for (size_t i = 1; i < 14; ++i)
	{
		vec_two[0] = { 30.f + (float)i * 40.f , 570.f };
		vec_two[1] = { 50.f + (float)i * 40.f, 550.f };
		vec_two[2] = { 70.f + (float)i * 40.f , 570.f };
		m_shapes.push_back(new Triangle(vec_two));
		size = m_shapes.size();
		bot.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	}

	vec_two[0] = { 610.f , 570.f };
	vec_two[1] = { 610.f , 550.f };
	vec_two[2] = { 590.f , 570.f };
	m_shapes.push_back(new Triangle(vec_two));
	size = m_shapes.size();
	bot.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	
	//Sides lines
	for (int i = 0; i < 12; ++i)
	{
		vec_one[0] = { 50.f, 70.f + float(i * 40.f) };
		vec_one[1] = { 50.f, 110.f + float(i * 40.f) };
		vec_one[2] = { 70.f, 90.f + float(i * 40.f) };
		m_shapes.push_back(new Triangle(vec_one));
		int size = m_shapes.size();
		side.push_back({ EDGE, {m_shapes[size - 1], NULL } });

		vec_two[0] = { 610.f, 70.f + float(i * 40.f) };
		vec_two[1] = { 610.f, 110.f + float(i * 40.f) };
		vec_two[2] = { 590.f, 90.f + float(i * 40.f) };
		m_shapes.push_back(new Triangle(vec_two));
		size = m_shapes.size();
		side.push_back({ EDGE, {m_shapes[size - 1], NULL } });
	}

	m_board.push_back(top);
	m_board.push_back(bot);
	m_board.push_back(side);
}

void Board::centerMat()
{
	l_type mid;
	Shape_kind sk;
	int size;

	for (int m = 1; m < 27; ++m)
	{
		if(m % 2 == 0)
		{
			for (int i = 0; i < 13; ++i)
			{
				for (int j = 0; j < 14; ++j)
				{
					sk = get();
					switch (sk)
					{
					case DIAMOND:
					default:
						vec_dia[0] = { 70.f + float(j * 40.f), 50.f + float(i * 40.f) };
						vec_dia[1] = { 50.f + float(j * 40.f), 70.f + float(i * 40.f) };
						vec_dia[2] = { 70.f + float(j * 40.f), 90.f + float(i * 40.f) };
						vec_dia[3] = { 90.f + float(j * 40.f), 70.f + float(i * 40.f) };
						m_shapes.push_back(new Diamond(vec_dia));
						size = m_shapes.size();
						mid.push_back({ DIAMOND, {m_shapes[size - 1], NULL } });
						break;

					case TRAINGLE_HOR:
						vec_one[0] = { 50.f, 70.f + float(i * 40.f) };
						vec_one[1] = { 70.f, 50.f + float(i * 40.f) };
						vec_one[2] = { 90.f, 70.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						vec_one[0] = { 50.f, 70.f + float(i * 40.f) };
						vec_one[1] = { 70.f, 90.f + float(i * 40.f) };
						vec_one[2] = { 90.f, 70.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						size = m_shapes.size();
						mid.push_back({ TRAINGLE_HOR, {m_shapes[size - 2], m_shapes[size - 1] } });
						break;

					case TRAINGLE_VER:
						vec_one[0] = { 70.f, 50.f + float(i * 40.f) };
						vec_one[1] = { 50.f, 70.f + float(i * 40.f) };
						vec_one[2] = { 70.f, 90.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						vec_one[0] = { 70.f, 50.f + float(i * 40.f) };
						vec_one[1] = { 90.f, 70.f + float(i * 40.f) };
						vec_one[2] = { 70.f, 90.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						size = m_shapes.size();
						mid.push_back({ TRAINGLE_VER, {m_shapes[size - 2], m_shapes[size - 1] } });
						break;
					}

				}
			}
			m_board.push_back(mid);
		}
		else
		{
			for (int i = 0; i < 12; ++i)
			{
				for (int j = 0; j < 13; ++j)
				{
					sk = get();
					switch (sk)
					{
					case DIAMOND:
					default:
						vec_dia[0] = { 90.f + float(j * 40.f), 70.f + float(i * 40.f) };
						vec_dia[1] = { 70.f + float(j * 40.f), 90.f + float(i * 40.f) };
						vec_dia[2] = { 90.f + float(j * 40.f), 110.f + float(i * 40.f) };
						vec_dia[3] = { 110.f + float(j * 40.f), 90.f + float(i * 40.f) };
						m_shapes.push_back(new Diamond(vec_dia));
						size = m_shapes.size();
						mid.push_back({ DIAMOND, {m_shapes[size - 1], NULL } });
						break;

					case TRAINGLE_HOR:
						vec_one[0] = { 90.f, 70.f + float(i * 40.f) };
						vec_one[1] = { 70.f, 90.f + float(i * 40.f) };
						vec_one[2] = { 110.f, 90.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						vec_one[0] = { 70.f, 90.f + float(i * 40.f) };
						vec_one[1] = { 90.f, 110.f + float(i * 40.f) };
						vec_one[2] = { 110.f, 90.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						size = m_shapes.size();
						mid.push_back({ TRAINGLE_HOR, {m_shapes[size - 2], m_shapes[size - 1] } });
						break;

					case TRAINGLE_VER:
						vec_one[0] = { 90.f, 70.f + float(i * 40.f) };
						vec_one[1] = { 70.f, 90.f + float(i * 40.f) };
						vec_one[2] = { 90.f, 110.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						vec_one[0] = { 90.f, 70.f + float(i * 40.f) };
						vec_one[1] = { 110.f, 90.f + float(i * 40.f) };
						vec_one[2] = { 90.f, 110.f + float(i * 40.f) };
						m_shapes.push_back(new Triangle(vec_one));

						size = m_shapes.size();
						mid.push_back({ TRAINGLE_VER, {m_shapes[size - 2], m_shapes[size - 1] } });
						break;
					}
				}
			}
			m_board.push_back(mid);
		}
	}
}

Shape_kind Board::get()
{
	return Shape_kind((rand() % 4) - 1);
}

void Board::neighbors()
{
	int c1 = 1;
	for (size_t i = 0; i < m_board.size(); ++i)
	{

		for (size_t j = 0; j < m_board[i].size(); ++j)
		{

			switch (m_board[i][j].first)
			{
			case EDGE:
				if (i > 0 && j > 0 && i < m_board.size() - 1)
				{
					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j - 1]);
					m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j - 1]);
				}
				else if (i > 0 && j == 0 && i < m_board.size() - 1)
				{
					m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j]);
					m_board[i][j].second.first->setDownRightNeib(m_board[i + 1][j]);
				}
				else if (i == 0)
				{
					if (j != m_board[i].size() - 1)
						m_board[i][j].second.first->setDownRightNeib(m_board[i + 1][j]);
					if (j > 0)
						m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j - 1]);
				}
				else
				{
					if (j != m_board[i].size() - 1)
						m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j]);
					if (j > 0)
						m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j - 1]);
				}
				break;
			case DIAMOND:
				if (i % 2 == 0)
				{
					m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j]);
					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j - 1]);
					m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j - 1]);
					m_board[i][j].second.first->setDownRightNeib(m_board[i + 1][j]);
				}
				else
				{
					m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j + 1]);
					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j]);
					m_board[i][j].second.first->setDownRightNeib(m_board[i + 1][j + 1]);
					m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j]);

				}
				break;
			case TRAINGLE_VER:
				m_board[i][j].second.first->setTriNeib(m_board[i][j].second.second);
				m_board[i][j].second.second->setTriNeib(m_board[i][j].second.first);

				if (i % 2 == 0)
				{
					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j - 1]);
					m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j - 1]);
					m_board[i][j].second.second->setUpRightNeib(m_board[i - 1][j]);
					m_board[i][j].second.second->setDownRightNeib(m_board[i + 1][j]);
				}
				else
				{

					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j]);
					m_board[i][j].second.first->setDownLeftNeib(m_board[i + 1][j]);
					m_board[i][j].second.second->setUpRightNeib(m_board[i - 1][j + 1]);
					m_board[i][j].second.second->setDownRightNeib(m_board[i + 1][j + 1]);

				}
				break;
			case TRAINGLE_HOR:
				m_board[i][j].second.first->setTriNeib(m_board[i][j].second.second);
				m_board[i][j].second.second->setTriNeib(m_board[i][j].second.first);


				if (i % 2 == 0)
				{

					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j - 1]);
					m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j]);
					m_board[i][j].second.second->setDownLeftNeib(m_board[i + 1][j - 1]);
					m_board[i][j].second.second->setDownRightNeib(m_board[i + 1][j]);
				}
				else
				{

					m_board[i][j].second.first->setUpLeftNeib(m_board[i - 1][j]);
					m_board[i][j].second.first->setUpRightNeib(m_board[i - 1][j + 1]);
					m_board[i][j].second.second->setDownLeftNeib(m_board[i + 1][j]);
					m_board[i][j].second.second->setDownRightNeib(m_board[i + 1][j + 1]);

				}
				break;
			}
		}
	}
}
