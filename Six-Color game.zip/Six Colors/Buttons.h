#pragma once
#include <SFML/Graphics.hpp>

class Controller;
class Buttons
{
public:
	Buttons();
	~Buttons();
	virtual void clickedOn(Controller &) = 0;
	bool contains(sf::Vector2f &, int);
	bool containsGameButtons(sf::Vector2f &, int);

private:
	const sf::Texture *m_texture;
};