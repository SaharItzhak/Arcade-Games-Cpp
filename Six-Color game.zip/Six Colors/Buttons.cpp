#include "Buttons.h"
#include "Controller.h"


Buttons::Buttons()
{
}

Buttons::~Buttons()
{
}

bool Buttons::contains(sf::Vector2f & pos, int i)
{
	sf::RectangleShape r({ 38.f, 38.f });
	r.setPosition(94 * (i + 1), 602);
	return r.getGlobalBounds().contains(pos.x, pos.y);
}

bool Buttons::containsGameButtons(sf::Vector2f & pos, int i)
{
	sf::RectangleShape r({ 100.f, 51.f });
	r.setPosition(1 * (i * 100), 0);
	return r.getGlobalBounds().contains(pos.x, pos.y);
}

