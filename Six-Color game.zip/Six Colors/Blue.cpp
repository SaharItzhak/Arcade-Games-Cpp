#include "Blue.h"
#include "Controller.h"

Blue::Blue()
{
}

Blue::~Blue()
{
}

void Blue::clickedOn(Controller & c)
{
	c.blue();
}
