#include "Red.h"
#include "Controller.h"

Red::Red()
{
}

Red::~Red()
{
}

void Red::clickedOn(Controller & c)
{
	c.red();
}
