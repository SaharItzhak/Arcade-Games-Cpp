#include "Triangle.h"



Triangle::Triangle(std::vector<sf::Vector2f> vec) : Shapes(VERTEX_TR, vec)
{
}


Triangle::~Triangle()
{
}
