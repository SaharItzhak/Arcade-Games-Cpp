#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Utilities.h"
#include "GameButtons.h"
#include "ColorButtons.h"
#include "User.h"

class Controller
{
public:
	Controller();
	~Controller();
	void run();
	void event();
	void drawTool();
	void buttons();
	void blue();
	void green();
	void white();
	void magenta();
	void red();
	void yellow();
	void restart();
	void exit();

private:
	sf::RenderWindow m_window;

	std::vector<GameButtons *> m_gameButton;
	std::vector<ColorButtons *> m_colorButtons;
	std::vector<sf::FloatRect> spriteSize;

	User u;
};
