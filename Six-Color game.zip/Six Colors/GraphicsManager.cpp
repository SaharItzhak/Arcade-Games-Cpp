#include "GraphicsManager.h"



GraphicsManager::GraphicsManager()
{
	m_textures_tool.resize(TOOL_BAR);
	m_textures_colors.resize(COLORS);
	loadPictures(m_textures_tool, TOOL_BAR, "Tool/" );
	loadPictures(m_textures_colors, COLORS, "Colors/");
}

void GraphicsManager::loadPictures(std::vector <sf::Texture>& textures, int N, std::string sub_folder)
{
	const std::string pictureFolder("Images/" + sub_folder);
	const std::string pictureType(".png");
	for (int i = 0; i < N; i++)
	{
		//convert to string
		std::string picture_path = pictureFolder + std::to_string(i) + pictureType;
		//insert to toolbar
		textures[i].loadFromFile(picture_path);
	}
}

GraphicsManager::~GraphicsManager()
{
}

GraphicsManager & GraphicsManager::get_instance()
{
	static GraphicsManager instance;

	return instance;
}

const sf::Texture * GraphicsManager::getTexture(const int i) const
{
	return &m_textures_tool[i];
}

const sf::Texture * GraphicsManager::getTextureColor(const int i) const
{
	return &m_textures_colors[i];
}
