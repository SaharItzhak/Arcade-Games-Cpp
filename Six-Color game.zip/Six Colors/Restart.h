#pragma once
#include "GameButtons.h"

class Restart : public GameButtons
{
public:
	Restart();
	~Restart();
	virtual void clickedOn(Controller &);
};

