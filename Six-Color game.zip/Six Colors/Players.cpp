#include "Players.h"



Players::Players()
{
}


Players::~Players()
{
}

void Players::start(Shapes * s)
{
	//m_start = start;

	m_setShapes.insert(s);
}