OOP2
EX4

Sahar Itzhak 308389485 
Ron Efraim 204661425.

Program:
The goal of this game is to paint as large area as possible. 
By selecting the proper color you attach the neighboring tiles of the same color to your posession. 
You start from the lower left, your opponent (computer) starts from the upper right. 
The player who takes over 50% of the board wins.


Files:
- Board: Board.h & Board.cpp
	Build the matrix of shapes

- Buttons: Buttons.h & Buttons.cpp
	 Handle the game buttons (restart, exit and colors)
	- GameButtons: GameButtons.h & GameButtons.cpp - Handle restart and exit buttons.
		- Restart: Restart.h & Restart.cpp
		- Exit: Exit.h & Exit.cpp
	- ColorButtons: ColorButtons.h & ColorButtons.cpp- Handle colors buttons.
		- Blue: Blue.h & Blue.cpp
		- Green: Green.h & Green.cpp
		- Magenta: Magenta.h & Magenta.cpp
		- Red: Red.h & Red.cpp
		- White: White.h & White.cpp
		- Yellow: Yellow.h & Yellow.cpp

- Controller: Controller.h & Controller.cpp:
	    Handle all the movements in the game.

- GraphicManager: GraphicManager.h & GraphicManager.cpp
		  Loaded the images and save them.

- Players: Players.h & players.cpp
	 Handle the movement.
	- User: User.h & User.cpp - Handle the user movement (pick colors).
	- Computer: Computer.h & computer.cpp - Handle the computer movement.

- Shapes: Shapes.h & Shapes.cpp
	   handle the images and draw them.
	- Diamond: Diamond.h & Diamond.cpp
	- Triangle: Triangle.h & Triangle.cpp
 
- Utilities: Utilities.h & Controller.cpp:
	     Handle all the Shapes in the game.

Bugs:
Not everything works.