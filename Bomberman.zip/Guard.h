#pragma once
#include "Utilities.h"
#include "Board.h"


class Guard
{
public:
	Guard();
	void move(Board& board,const Vertex &playerPos);

private:
	Vertex m_location;
};

