#pragma once

#include "characteristics.h"
#include <windows.h>
#include <cmath>

struct Vertex
{
	int m_x;
	int m_y;
	bool in_range(int size) const;

};

/*
struct Position
{
	short row;
	short col;
};
*/
double distance(const Vertex& v1, const Vertex& v2);
void moveCursor(const Vertex& pos);