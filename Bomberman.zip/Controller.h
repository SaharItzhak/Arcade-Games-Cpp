#pragma once
#include "Board.h"
#include "player.h"
#include <cstdlib>


class Controller
{
		
public:
	void run();
	Controller() = default;

private:
	Board m_board;
	player m_player;
};

