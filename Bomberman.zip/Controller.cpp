#include "Controller.h"


void Controller::run()
{
	/*
	while(!GameOver)
	{
		clearScreen()
		print()
		moveP_layer
		moveGuard
		updateBoard

		if(levelOver)
			m_board.read_file();
	}
	*/
	int level = 0;
	while (1)
	{
		if(level == 0)
			m_board.fill_board();
		system("cls");
		m_board.print();
		m_player.handleSpecialKey(m_board);
		//m_board.updatePrint(m_player.m_curr_location);
		level++;
		
	}
}
