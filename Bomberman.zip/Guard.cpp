#include "Guard.h"
#include "Utilities.h"

Guard::Guard() :m_location({ 1,1 })
{
}

unsigned int min_dist;
Vertex guard_pos;

void Guard::move(Board& board,const Vertex& playerPos)
{
	//up
	min_dist = distance(playerPos, { m_location.m_x, m_location.m_y - 1 });
	guard_pos = guard_pos = { m_location.m_x, m_location.m_y - 1 };

	//down
	if (min_dist < distance(playerPos, { m_location.m_x, m_location.m_y + 1 }))
	{
		min_dist = distance(playerPos, { m_location.m_x, m_location.m_y + 1 });
		guard_pos = { m_location.m_x, m_location.m_y + 1 };
	}

	//left
	if (min_dist < distance(playerPos, { m_location.m_x - 1, m_location.m_y }))
	{
		min_dist = distance(playerPos, { m_location.m_x - 1, m_location.m_y });
		guard_pos = { m_location.m_x - 1, m_location.m_y };
	}

	//right
	if (min_dist < distance(playerPos, { m_location.m_x + 1, m_location.m_y }))
	{
		min_dist = distance(playerPos, { m_location.m_x + 1, m_location.m_y });
		guard_pos = { m_location.m_x + 1, m_location.m_y };
	}


	if (board.can_walk(guard_pos))
	{
		Vertex m_next_location = guard_pos;
		Vertex m_curr_location = m_location;
		board.updatePrint(m_next_location, m_curr_location);
		m_curr_location = m_next_location;
	}
}