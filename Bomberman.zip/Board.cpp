#include "Board.h"


Board::Board()
{
	open_file();
}

void Board::fill_board()
{
	int size_of_board;
	int steps;
	unsigned int guards = 0;

	file >> size_of_board;
	file >> steps;

	//board of rocks and walls

	m_statBoard.resize(size_of_board);
	m_playerBoard.resize(size_of_board);

	for (int row = 0; row < size_of_board; row++)
	{
		for (int col = 0; col < size_of_board; col++)
		{
			char c = file.get();  //gets a char from the file
			
			if (c == '/')
			{
				m_playerBoard[row].push_back(c);
				c = SPACE;
			}
				
			else if (c == '!')
			{
				guards++;
				m_playerBoard[row].push_back(c);
				c = SPACE;
			}

			else if (c == '\n')
			{
				col--;	
				continue;
				//fixa
			}

			else 
			{
				m_playerBoard[row].push_back(' ');
			}
			
			m_statBoard[row].push_back(c);
		}
		
	}
}

void Board::print()
{
	//m_dynamicBoard = m_matrix //this copies all statics onto dynamic board

	//Vrtex playerPos = playerPos 
	// run on vector of gaurds get their positions

	//m_dynamicBoard[playerpos] = '\'
	//in a loop for each guard :
			// m_dynamicBoard[guardPos] = '!'
	//m_playerBoard = m_statBoard;


	for (int i = 0; i < m_statBoard.size(); i++)
	{
		for (int j = 0; j < m_statBoard.size(); j++)
		{

			if (m_playerBoard[i][j] != ' ')
			{
				std::cout << m_playerBoard[i][j];
				//char pos_player = m_playerBoard[i][j];
			}

			else
				std::cout << m_statBoard[i][j];
		}

		std::cout << std::endl;
	}
}

void Board::updatePrint(const Vertex newPos,const Vertex oldPos)
{
	//moveCursor(temp);
	m_playerBoard[oldPos.m_y][oldPos.m_x] = ' ';
	m_playerBoard[newPos.m_y][newPos.m_x]  = '/';
	//std::cout << m_playerBoard[temp.m_y][temp.m_x];
}


void Board::open_file()
{
	file.open("Board.txt");

	if (!file.is_open())
	{
		std::cerr << "The file failed to open";
	}
}


bool Board::can_walk(Vertex v)
{
	if(v.in_range(m_statBoard.size()) && (m_statBoard[v.m_y][v.m_x] != WALL && m_statBoard[v.m_y][v.m_x] != ROCK))
		return true;

	return false;
}

