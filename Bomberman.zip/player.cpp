#include "player.h"



player::player(Vertex &location) : m_life(LIFE), m_curr_location(location), m_prev_location(location)
{
}

void player::hit()
{
	if (m_life == 0)
		exit(EXIT_SUCCESS);
		/*return beemet?*/

	m_life--;
}

void player::handleSpecialKey(Board& board)
{
	Vertex newVer = { 0,0 };

	switch (Keyboard::getch())
		{
		case 0:
		case SPECIAL_KEY:
			int c = Keyboard::getch();
			switch (c)
			{
			case KB_UP:
				newVer = { m_curr_location.m_x,m_curr_location.m_y - 1 };
				break;

			case KB_DOWN:
				newVer = { m_curr_location.m_x,m_curr_location.m_y + 1 };
				break;

			case KB_LEFT:
				newVer = { m_curr_location.m_x - 1,m_curr_location.m_y };
				break;

			case KB_RIGHT:
				newVer = { m_curr_location.m_x + 1,m_curr_location.m_y };
				break;

			default:
				std::cout << "Unknown special key pressed (code = " << c << ")" << std::endl;
				break;
			}
			break;
		}
		if (board.can_walk(newVer))
		{
			Vertex m_next_location = newVer;
			//moveCursor(m_curr_location);
			board.updatePrint(m_next_location, m_curr_location);
			m_curr_location = m_next_location;
		}
}