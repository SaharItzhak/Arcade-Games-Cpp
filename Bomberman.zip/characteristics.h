#pragma once

#define LIFE 3
#define Player '/'
#define WALL '#'
#define ROCK '@'
#define BOMB 'b'
#define SPACE ' '
#define ENEMY '!'
#define DOOR 'D'
