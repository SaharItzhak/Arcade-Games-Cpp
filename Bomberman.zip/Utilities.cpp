#include "Utilities.h"


bool Vertex::in_range(int size) const
{
	return(m_x >= 0 && m_x < size && m_y >= 0 && m_y < size);
}

void moveCursor(const Vertex & pos)
{
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), {(short) pos.m_y, (short) pos.m_x });
}

double distance(const Vertex& v1, const Vertex& v2)
{
	return std::sqrt(std::pow((v1.m_x - v2.m_x), 2)
		+ std::pow((v1.m_y - v2.m_y), 2));
}