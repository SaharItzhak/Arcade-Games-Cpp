#include <iostream>
#include "Board.h"
#include "Controller.h"

int main()
{
	Controller control;

	control.run();
	getchar();
	return 0;
}