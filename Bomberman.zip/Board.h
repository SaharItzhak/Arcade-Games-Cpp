#pragma once
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <vector>
#include "Utilities.h"
#include <windows.h>

class Board
{
public:
	void fill_board();
	bool can_walk(Vertex);
	void print();
	Board();
	//Vertex getVertex(Vertex);
	void updatePrint(const Vertex, const Vertex);
	void printGuard(Vertex);

private:
	std::ifstream file;
	std::vector<std::vector<char>> m_playerBoard;  //2D matrix of chars 
	std::vector<std::vector<char>> m_statBoard;
	void open_file();
};

