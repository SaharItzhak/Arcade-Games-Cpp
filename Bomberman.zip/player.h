#pragma once
#include <conio.h>
#include <cstdlib>
#include "Utilities.h"
#include "characteristics.h"
#include "Board.h"
//#include <vector>
#include "Keyboard.h"

//using std::vector;

class player
{
public:
	player(Vertex &);
	void hit();
	void handleSpecialKey(Board& board);
	player() = default;
	Vertex m_curr_location;

private:
	unsigned int m_life;
	
	Vertex m_prev_location;

};

